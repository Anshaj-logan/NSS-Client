import React from 'react'

const Hero = () => {
  return (
    <div>
        
        <>
  {/* ======= Hero Section ======= */}
  <section id="hero" className="d-flex align-items-center">
    <div
      className="container text-center position-relative"
      data-aos="fade-in"
      data-aos-delay={200}
    >
      <h1>NSS MANAGEMENT SYSTEM</h1>
      <h2>IDEAL COLLEGE FOR ADVANCED STUDIES</h2>
      {/* <a href="#about" class="btn-get-started scrollto">Get Started</a> */}
    </div>
  </section>
  {/* End Hero */}
</>


    </div>
  )
}

export default Hero