import React from 'react'

const Login = () => {
  return (
    <div>
        <Loginn/>
    </div>
  )
}

export default Login