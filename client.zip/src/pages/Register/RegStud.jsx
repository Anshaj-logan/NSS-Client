import React from 'react'
import RegSu from '../../components/Register/RegSu'

const RegStud = () => {
  return (
    <div>
        <RegSu/>
    </div>
  )
}

export default RegStud