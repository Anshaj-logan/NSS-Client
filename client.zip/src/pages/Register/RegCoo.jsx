import React from 'react'
import RegCo from '../../components/Register/RegCo'

const RegCoo = () => {
  return (
    <div>
        <RegCo />
    </div>
  )
}

export default RegCoo