import React from 'react'
import RegAl from '../../components/Register/RegAl'

const RegAlu = () => {
  return (
    <div>
        <RegAl/>
    </div>
  )
}

export default RegAlu