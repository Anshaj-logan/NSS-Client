import React from 'react'
import RegVo from '../../components/Register/RegVo'

const RegVol = () => {
  return (
    <div>
        <RegVo />
    </div>
  )
}

export default RegVol